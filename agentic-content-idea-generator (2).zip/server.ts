import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Lazy-loaded Gemini AI client to prevent startup crashes if key is empty
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not set. Please add it in Settings > Secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

async function callGeminiWithRetry<T>(
  apiCall: (modelName: string) => Promise<T>,
  retries = 3,
  delay = 1500,
  useFallbackModel = false,
  modelIndex = 0
): Promise<T> {
  const models = ["gemini-3.5-flash", "gemini-flash-latest", "gemini-3.1-flash-lite"];
  
  let activeIndex = modelIndex;
  if (useFallbackModel && activeIndex === 0) {
    activeIndex = 1;
  }
  
  const modelName = models[activeIndex] || models[models.length - 1];
  try {
    return await apiCall(modelName);
  } catch (error: any) {
    const errorStr = String(error?.message || error || "");
    const status = error?.status || error?.statusCode || 0;
    
    const isTransient = 
      status === 503 || 
      status === 429 || 
      errorStr.includes("503") ||
      errorStr.includes("429") ||
      errorStr.includes("high demand") ||
      errorStr.includes("UNAVAILABLE") ||
      errorStr.includes("RESOURCE_EXHAUSTED") ||
      errorStr.includes("overloaded") ||
      errorStr.includes("Quota exceeded") ||
      errorStr.includes("quota");

    if (isTransient) {
      // If we have fallback models left in the chain, fall back immediately to bypass quota/demand issues
      if (activeIndex < models.length - 1) {
        const nextModel = models[activeIndex + 1];
        console.warn(`Gemini API returned transient error/quota exceeded for ${modelName} (status ${status}). Falling back immediately to ${nextModel}...`);
        return callGeminiWithRetry(apiCall, retries, delay, useFallbackModel, activeIndex + 1);
      }

      if (retries > 0) {
        console.warn(`Gemini API returned transient error for ${modelName} (status ${status}, retries left: ${retries}). Retrying in ${delay}ms...`, errorStr);
        await new Promise((resolve) => setTimeout(resolve, delay));
        return callGeminiWithRetry(apiCall, retries - 1, delay * 2, useFallbackModel, activeIndex);
      }
    }
    throw error;
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Use JSON parsing with a generous size limit for rich payloads
  app.use(express.json({ limit: "15mb" }));

  // API endpoint for content generation
  app.post("/api/generate", async (req, res) => {
    try {
      const { topic, audience, industry, contentGoal, platforms } = req.body;

      if (!topic || !audience || !industry || !contentGoal || !platforms || !platforms.length) {
        return res.status(400).json({ error: "Missing required fields (topic, audience, industry, contentGoal, platforms)." });
      }

      const ai = getGeminiClient();

      /* ORIGINAL SINGLE-CALL VERSION — uncomment to revert
      const analysisPrompt = `You are an elite growth-oriented Content Strategist, Search Analyst, and Editorial Director.
Generate a comprehensive, non-cliché, highly specific editorial blueprint for the following parameters:

Topic Area: "${topic}"
Audience Segment: "${audience}"
Industry Vertical: "${industry}"
Primary Conversion Goal: "${contentGoal}"
Target Distribution Mediums: ${platforms.join(", ")}

Perform these exact 7 steps to formulate your master plan:
- Step 1 (Audience Analysis): Detail primary and secondary cohorts, deep challenges, frequent real-world queries, mental blocks, and target outcomes.
- Step 2 (Search Intent Mapping): Generate EXACTLY 20 highly specific search/social intent vectors spread across Informational, Commercial, Transactional, Emerging, and Contrarian.
- Step 3 (Editorial Gap Analysis): Examine the landscape. Outline saturated clichès, boring overdone titles, missing active discussions, tough questions people dodge, and contrarian perspectives.
- Step 4 (Idea Generation): Craft exactly 10 blog concepts, 10 LinkedIn ideas, and 10 Newsletter formats.
- Step 5 (Idea Scoring): Score each of these 30 items 1-10 on Novelty, Audience Relevance, Business Value, Search Opportunity, and Shareability, producing a mathematically calculated average overall score (1.0 - 10.0).
- Step 6 (Prioritization): Order the aggregate ideas list by their scoring to extract the top 5 high-leverage concepts. Provide distinct reasons for prioritization, format suggestions, and brief.
- Step 7 (Execution Brief): Take the single #1 highest-scored prospect. Author a deep production brief containing a systematic outline, talking points, concrete lead magnet, and high-converting CTA copy.

Deliver your strategic blueprint strictly respecting the JSON output schema. Avoid filler text and generic boilerplate advice. Populate values with specific, data-rich terms customized specifically for "${topic}" in the context of "${industry}".`;

      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          audienceAnalysis: {
            type: Type.OBJECT,
            properties: {
              primaryAudience: { type: Type.STRING, description: "Detailed persona profiles of primary buyers/readers" },
              secondaryAudience: { type: Type.STRING, description: "Detailed persona profiles of secondary influencers/adopters" },
              goals: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Direct objectives the readers are evaluated on" },
              painPoints: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Real-world friction points, operational leaks, or daily frustrations" },
              frequentQuestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Specific verbatim questions target readers ask online or in meetings" },
              objections: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Internal or organizational barriers to adopting this topic's concepts" },
              desiredOutcomes: { type: Type.ARRAY, items: { type: Type.STRING }, description: "What maximum success or validation looks like for them" }
            },
            required: ["primaryAudience", "secondaryAudience", "goals", "painPoints", "frequentQuestions", "objections", "desiredOutcomes"]
          },
          searchIntentMapping: {
            type: Type.OBJECT,
            properties: {
              opportunities: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    topic: { type: Type.STRING, description: "Highly specific keyword phrase or content concept structure" },
                    intent: { type: Type.STRING, description: "Category string, must be one of: Informational, Commercial, Transactional, Emerging, Contrarian" },
                    description: { type: Type.STRING, description: "Analysis of reader search intent and emotional trigger" }
                  },
                  required: ["topic", "intent", "description"]
                },
                description: "List of exactly 20 diverse search/topic intent opportunities mapping out user journeys."
              }
            },
            required: ["opportunities"]
          },
          editorialGapAnalysis: {
            type: Type.OBJECT,
            properties: {
              saturatedIdeas: { type: Type.ARRAY, items: { type: Type.STRING }, description: "The most common and boring topics in this niche that we should avoid doing raw" },
              overusedAngles: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Tired content hooks, clickbait clichés, and overplayed narratives" },
              missingConversations: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Crucial sub-discussions or systemic realities that are weirdly neglected" },
              underservedQuestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Highly technical or difficult questions that current search results fail to answer" },
              counterintuitiveInsights: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Strong, truth-based contrarian perspectives that break conventional consensus" },
              summary: { type: Type.STRING, description: "A high-level synthesis outlining how to win by filling these specific gaps (150-200 words)" }
            },
            required: ["saturatedIdeas", "overusedAngles", "missingConversations", "underservedQuestions", "counterintuitiveInsights", "summary"]
          },
          blogIdeas: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING, description: "Highly optimized, original article headline" },
                targetAudience: { type: Type.STRING },
                searchIntent: { type: Type.STRING, description: "e.g., Commercial, Transactional, etc." },
                whyItMatters: { type: Type.STRING, description: "Why this article commands active reading time" },
                difficulty: { type: Type.STRING, description: "Must be: Low, Medium, High" },
                impact: { type: Type.STRING, description: "Must be: Low, Medium, High" },
                scores: {
                  type: Type.OBJECT,
                  properties: {
                    novelty: { type: Type.NUMBER, description: "Integer 1-10 based on how rare/original this content concept is" },
                    audienceRelevance: { type: Type.NUMBER, description: "Integer 1-10 based on alignment with pain points" },
                    businessValue: { type: Type.NUMBER, description: "Integer 1-10 based on product alignment/lead potential" },
                    searchOpportunity: { type: Type.NUMBER, description: "Integer 1-10 based on search volume to programmatic competition ratio" },
                    shareability: { type: Type.NUMBER, description: "Integer 1-10 based on emotional triggers, controversy, or visual ease" },
                    overallScore: { type: Type.NUMBER, description: "Average score calculated from the 5 scoring parameters" }
                  },
                  required: ["novelty", "audienceRelevance", "businessValue", "searchOpportunity", "shareability", "overallScore"]
                }
              },
              required: ["id", "title", "targetAudience", "searchIntent", "whyItMatters", "difficulty", "impact", "scores"]
            }
          },
          linkedinIdeas: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                hook: { type: Type.STRING, description: "Attention-grabbing hook line designed to stop scroll" },
                coreInsight: { type: Type.STRING, description: "The single high-impact thesis or framework" },
                engagementPotential: { type: Type.STRING, description: "Must be: Low, Medium, High" },
                suggestedCTA: { type: Type.STRING, description: "Conversion or discussion oriented CTAs" },
                scores: {
                  type: Type.OBJECT,
                  properties: {
                    novelty: { type: Type.NUMBER },
                    audienceRelevance: { type: Type.NUMBER },
                    businessValue: { type: Type.NUMBER },
                    searchOpportunity: { type: Type.NUMBER },
                    shareability: { type: Type.NUMBER },
                    overallScore: { type: Type.NUMBER }
                  },
                  required: ["novelty", "audienceRelevance", "businessValue", "searchOpportunity", "shareability", "overallScore"]
                }
              },
              required: ["id", "hook", "coreInsight", "engagementPotential", "suggestedCTA", "scores"]
            }
          },
          newsletterIdeas: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                subjectLine: { type: Type.STRING, description: "Punchy email subject line designed for top open rates" },
                angle: { type: Type.STRING, description: "Storytelling setup, case study framework, or thought-experiments used as hook" },
                keyTakeaway: { type: Type.STRING, description: "The exact practical lesson a reader holds afterwards" },
                whySubscribersCare: { type: Type.STRING, description: "Why users won't hit unsubscribe" },
                scores: {
                  type: Type.OBJECT,
                  properties: {
                    novelty: { type: Type.NUMBER },
                    audienceRelevance: { type: Type.NUMBER },
                    businessValue: { type: Type.NUMBER },
                    searchOpportunity: { type: Type.NUMBER },
                    shareability: { type: Type.NUMBER },
                    overallScore: { type: Type.NUMBER }
                  },
                  required: ["novelty", "audienceRelevance", "businessValue", "searchOpportunity", "shareability", "overallScore"]
                }
              },
              required: ["id", "subjectLine", "angle", "keyTakeaway", "whySubscribersCare", "scores"]
            }
          },
          prioritizedOpportunities: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                ideaId: { type: Type.STRING, description: "Must match one of the generated ids e.g. blog-X, linkedin-Y, newsletter-Z" },
                title: { type: Type.STRING, description: "Headline / Name of the content item" },
                whyItWon: { type: Type.STRING, description: "Detailed strategic analysis of why this scored highest (Novelty, search traffic, or brand conversion synergy)" },
                recommendedFormat: { type: Type.STRING, description: "Concrete suggested media asset type" },
                expectedOutcome: { type: Type.STRING, description: "High-level goal outcome e.g. lead downloads, thought authority, viral backlinks" },
                contentBriefString: { type: Type.STRING, description: "Detailed synopsis mapping out sections, format, and core thesis" }
              },
              required: ["ideaId", "title", "whyItWon", "recommendedFormat", "expectedOutcome", "contentBriefString"]
            },
            description: "Top 5 high-leverage content concepts extracted directly based on highest aggregate scores."
          },
          executionBrief: {
            type: Type.OBJECT,
            properties: {
              workingTitle: { type: Type.STRING, description: "The final production title locked in" },
              targetKeyword: { type: Type.STRING, description: "High-level primary keyword with semantic search variations" },
              audience: { type: Type.STRING, description: "Segment target definition" },
              searchIntent: { type: Type.STRING },
              outline: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Comprehensive structural hierarchy (H2 / H3 milestones)" },
              keyTalkingPoints: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Specific points, insights, diagrams, stats, or frameworks to argue" },
              recommendedCTA: { type: Type.STRING, description: "Conversion link copy, inline triggers, or direct actions" },
              suggestedInternalLinks: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Supporting pillar pages or adjacent topics to link back to or link out" },
              suggestedLeadMagnet: { type: Type.STRING, description: "High-value asset (templates, cheat sheets, video audits, calculatros) designed to secure lead information" }
            },
            required: ["workingTitle", "targetKeyword", "audience", "searchIntent", "outline", "keyTalkingPoints", "recommendedCTA", "suggestedInternalLinks", "suggestedLeadMagnet"]
          }
        },
        required: ["audienceAnalysis", "searchIntentMapping", "editorialGapAnalysis", "blogIdeas", "linkedinIdeas", "newsletterIdeas", "prioritizedOpportunities", "executionBrief"]
      };

      const result = await callGeminiWithRetry((modelName) => 
        ai.models.generateContent({
          model: modelName,
          contents: analysisPrompt,
          config: {
            responseMimeType: "application/json",
            responseSchema,
            temperature: 0.2, // structured strategy prefers consistency, low temperature
          },
        })
      );

      const responseText = result.text;
      if (!responseText) {
        throw new Error("Empty response received from Gemini.");
      }

      const reportData = JSON.parse(responseText.trim());
      */

      // --- MULTI-AGENT SEQUENTIAL GENERATION ENGINE ---

      // Call 1 — Audience Analysis
      const schemaStep1 = {
        type: Type.OBJECT,
        properties: {
          primaryAudience: { type: Type.STRING },
          secondaryAudience: { type: Type.STRING },
          goals: { type: Type.ARRAY, items: { type: Type.STRING } },
          painPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
          frequentQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
          objections: { type: Type.ARRAY, items: { type: Type.STRING } },
          desiredOutcomes: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["primaryAudience", "secondaryAudience", "goals", "painPoints", "frequentQuestions", "objections", "desiredOutcomes"]
      };

      const result1 = await callGeminiWithRetry((modelName) => 
        ai.models.generateContent({
          model: modelName,
          contents: `You are the Audience Analyst Agent. Analyze this audience deeply.
Topic: ${topic}, Audience: ${audience}, 
Industry: ${industry}, Goal: ${contentGoal}
Return JSON with these fields: primaryAudience, secondaryAudience, goals, painPoints, frequentQuestions, objections, desiredOutcomes`,
          config: {
            responseMimeType: "application/json",
            responseSchema: schemaStep1,
            temperature: 0.2
          }
        })
      );
      if (!result1.text) {
        throw new Error("Step 1 (Audience Analysis) returned empty response.");
      }
      const step1 = JSON.parse(result1.text.trim());

      // Call 2 — Search Intent Mapping
      const schemaStep2 = {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            phrase: { type: Type.STRING },
            category: { type: Type.STRING },
            emotionalTrigger: { type: Type.STRING }
          },
          required: ["phrase", "category", "emotionalTrigger"]
        }
      };

      const result2 = await callGeminiWithRetry((modelName) => 
        ai.models.generateContent({
          model: modelName,
          contents: `You are the Search Intent Mapping Agent.
Audience analysis: ${JSON.stringify(step1)}
Topic: ${topic}, Industry: ${industry}
Generate exactly 20 search intent vectors across these categories:
Informational, Commercial, Transactional, Emerging, Contrarian.
Return as JSON array where each item has: phrase, category, emotionalTrigger`,
          config: {
            responseMimeType: "application/json",
            responseSchema: schemaStep2,
            temperature: 0.2
          }
        })
      );
      if (!result2.text) {
        throw new Error("Step 2 (Search Intent Mapping) returned empty response.");
      }
      const step2Raw = JSON.parse(result2.text.trim());
      const step2 = step2Raw.map((item: any) => ({
        phrase: item.phrase || item.topic || "",
        category: item.category || item.intent || "Informational",
        emotionalTrigger: item.emotionalTrigger || item.description || "",
        // Support original frontend UI property expectations
        topic: item.phrase || item.topic || "",
        intent: item.category || item.intent || "Informational",
        description: item.emotionalTrigger || item.description || ""
      }));

      // Call 3 — Gap Analysis
      const schemaStep3 = {
        type: Type.OBJECT,
        properties: {
          saturatedIdeas: { type: Type.ARRAY, items: { type: Type.STRING } },
          overusedAngles: { type: Type.ARRAY, items: { type: Type.STRING } },
          missingConversations: { type: Type.ARRAY, items: { type: Type.STRING } },
          underservedQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
          counterintuitiveInsights: { type: Type.ARRAY, items: { type: Type.STRING } },
          summary: { type: Type.STRING }
        },
        required: ["saturatedIdeas", "overusedAngles", "missingConversations", "underservedQuestions", "counterintuitiveInsights", "summary"]
      };

      const result3 = await callGeminiWithRetry((modelName) => 
        ai.models.generateContent({
          model: modelName,
          contents: `You are the Editorial Gap Analysis Agent.
Audience analysis: ${JSON.stringify(step1)}
Search intents: ${JSON.stringify(step2)}
Identify content gaps in this space.
Return JSON with these fields: saturatedIdeas, overusedAngles, missingConversations, underservedQuestions, counterintuitiveInsights, summary`,
          config: {
            responseMimeType: "application/json",
            responseSchema: schemaStep3,
            temperature: 0.1
          }
        })
      );
      if (!result3.text) {
        throw new Error("Step 3 (Gap Analysis) returned empty response.");
      }
      const step3 = JSON.parse(result3.text.trim());

      // Call 4 — Idea Generation
      const schemaStep4 = {
        type: Type.OBJECT,
        properties: {
          blogIdeas: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                hook: { type: Type.STRING },
                targetIntent: { type: Type.STRING },
                angle: { type: Type.STRING },
                targetAudience: { type: Type.STRING },
                searchIntent: { type: Type.STRING },
                whyItMatters: { type: Type.STRING },
                difficulty: { type: Type.STRING },
                impact: { type: Type.STRING }
              },
              required: ["id", "title", "hook", "targetIntent", "angle", "targetAudience", "searchIntent", "whyItMatters", "difficulty", "impact"]
            }
          },
          linkedinIdeas: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                hook: { type: Type.STRING },
                targetIntent: { type: Type.STRING },
                angle: { type: Type.STRING },
                coreInsight: { type: Type.STRING },
                engagementPotential: { type: Type.STRING },
                suggestedCTA: { type: Type.STRING }
              },
              required: ["id", "title", "hook", "targetIntent", "angle", "coreInsight", "engagementPotential", "suggestedCTA"]
            }
          },
          newsletterIdeas: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                hook: { type: Type.STRING },
                targetIntent: { type: Type.STRING },
                angle: { type: Type.STRING },
                subjectLine: { type: Type.STRING },
                keyTakeaway: { type: Type.STRING },
                whySubscribersCare: { type: Type.STRING }
              },
              required: ["id", "title", "hook", "targetIntent", "angle", "subjectLine", "keyTakeaway", "whySubscribersCare"]
            }
          }
        },
        required: ["blogIdeas", "linkedinIdeas", "newsletterIdeas"]
      };

      const result4 = await callGeminiWithRetry((modelName) => 
        ai.models.generateContent({
          model: modelName,
          contents: `You are the Content Idea Generator Agent.
Audience: ${JSON.stringify(step1)}
Gaps to fill: ${JSON.stringify(step3)}
Generate exactly 10 blog ideas with IDs blog-1 to blog-10,
10 LinkedIn ideas with IDs linkedin-1 to linkedin-10,
10 newsletter ideas with IDs newsletter-1 to newsletter-10.
Platforms requested: ${platforms.join(", ")}
Each idea needs: id, title, hook, targetIntent, angle
Return as JSON with three arrays: blogIdeas, linkedinIdeas, newsletterIdeas`,
          config: {
            responseMimeType: "application/json",
            responseSchema: schemaStep4,
            temperature: 0.3
          }
        })
      );
      if (!result4.text) {
        throw new Error("Step 4 (Idea Generation) returned empty response.");
      }
      const step4 = JSON.parse(result4.text.trim());

      // Call 5 — Scoring
      const scoreObjectSchema = {
        type: Type.OBJECT,
        properties: {
          novelty: { type: Type.NUMBER },
          audienceRelevance: { type: Type.NUMBER },
          businessValue: { type: Type.NUMBER },
          searchOpportunity: { type: Type.NUMBER },
          shareability: { type: Type.NUMBER },
          overallScore: { type: Type.NUMBER }
        },
        required: ["novelty", "audienceRelevance", "businessValue", "searchOpportunity", "shareability", "overallScore"]
      };

      const schemaStep5 = {
        type: Type.OBJECT,
        properties: {
          blogIdeas: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                hook: { type: Type.STRING },
                targetIntent: { type: Type.STRING },
                angle: { type: Type.STRING },
                targetAudience: { type: Type.STRING },
                searchIntent: { type: Type.STRING },
                whyItMatters: { type: Type.STRING },
                difficulty: { type: Type.STRING },
                impact: { type: Type.STRING },
                scores: scoreObjectSchema
              },
              required: ["id", "title", "hook", "targetIntent", "angle", "targetAudience", "searchIntent", "whyItMatters", "difficulty", "impact", "scores"]
            }
          },
          linkedinIdeas: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                hook: { type: Type.STRING },
                targetIntent: { type: Type.STRING },
                angle: { type: Type.STRING },
                coreInsight: { type: Type.STRING },
                engagementPotential: { type: Type.STRING },
                suggestedCTA: { type: Type.STRING },
                scores: scoreObjectSchema
              },
              required: ["id", "title", "hook", "targetIntent", "angle", "coreInsight", "engagementPotential", "suggestedCTA", "scores"]
            }
          },
          newsletterIdeas: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                hook: { type: Type.STRING },
                targetIntent: { type: Type.STRING },
                angle: { type: Type.STRING },
                subjectLine: { type: Type.STRING },
                keyTakeaway: { type: Type.STRING },
                whySubscribersCare: { type: Type.STRING },
                scores: scoreObjectSchema
              },
              required: ["id", "title", "hook", "targetIntent", "angle", "subjectLine", "keyTakeaway", "whySubscribersCare", "scores"]
            }
          }
        },
        required: ["blogIdeas", "linkedinIdeas", "newsletterIdeas"]
      };

      const result5 = await callGeminiWithRetry((modelName) => 
        ai.models.generateContent({
          model: modelName,
          contents: `You are the Content Scoring Agent.
Score every idea in this list on 5 dimensions: novelty, audienceRelevance, businessValue, searchOpportunity, shareability.
Each dimension scored 1-10. Overall = mathematical average to one decimal.
Force real differentiation — if scores cluster between 7 and 8 that is a failure state. Top ideas must clearly separate from bottom.
Ideas to score: ${JSON.stringify(step4)}
Return the same JSON structure with scores added to every idea.`,
          config: {
            responseMimeType: "application/json",
            responseSchema: schemaStep5,
            temperature: 0.1
          }
        })
      );
      if (!result5.text) {
        throw new Error("Step 5 (Scoring) returned empty response.");
      }
      const step5 = JSON.parse(result5.text.trim());

      // Backport the scored lists into step4 reference so reportData construction can reference step4 and get scores!
      step4.blogIdeas = step5.blogIdeas;
      step4.linkedinIdeas = step5.linkedinIdeas;
      step4.newsletterIdeas = step5.newsletterIdeas;

      // Call 6 — Prioritization
      const schemaStep6 = {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            ideaId: { type: Type.STRING },
            title: { type: Type.STRING },
            whyItWon: { type: Type.STRING },
            recommendedFormat: { type: Type.STRING },
            expectedOutcome: { type: Type.STRING },
            contentBriefString: { type: Type.STRING }
          },
          required: ["ideaId", "title", "whyItWon", "recommendedFormat", "expectedOutcome", "contentBriefString"]
        }
      };

      const result6 = await callGeminiWithRetry((modelName) => 
        ai.models.generateContent({
          model: modelName,
          contents: `You are the Content Prioritization Agent.
Select the top 5 ideas by overall score from this list.
Do not select two ideas with identical angles even if both scored highly.
For each of the top 5 provide: ideaId, title, whyItWon, recommendedFormat, expectedOutcome, contentBriefString
Rank them 1 to 5. Number 1 is the highest priority execution target.
Scored ideas: ${JSON.stringify(step5)}
Content goal: ${contentGoal}
Return as JSON array of 5 items.`,
          config: {
            responseMimeType: "application/json",
            responseSchema: schemaStep6,
            temperature: 0.2
          }
        })
      );
      if (!result6.text) {
        throw new Error("Step 6 (Prioritization) returned empty response.");
      }
      const step6 = JSON.parse(result6.text.trim());

      // Call 7 — Execution Brief
      const schemaStep7 = {
        type: Type.OBJECT,
        properties: {
          workingTitle: { type: Type.STRING },
          targetKeyword: { type: Type.STRING },
          audienceSegment: { type: Type.STRING },
          audience: { type: Type.STRING },
          searchIntent: { type: Type.STRING },
          outline: { type: Type.ARRAY, items: { type: Type.STRING } },
          keyTalkingPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
          recommendedCTA: { type: Type.STRING },
          suggestedInternalLinks: { type: Type.ARRAY, items: { type: Type.STRING } },
          suggestedLeadMagnet: { type: Type.STRING }
        },
        required: ["workingTitle", "targetKeyword", "audienceSegment", "audience", "searchIntent", "outline", "keyTalkingPoints", "recommendedCTA", "suggestedInternalLinks", "suggestedLeadMagnet"]
      };

      const result7 = await callGeminiWithRetry((modelName) => 
        ai.models.generateContent({
          model: modelName,
          contents: `You are the Execution Brief Agent.
Create one complete production-ready brief for this single top-ranked idea:
${JSON.stringify(step6[0] || {})}
Original context — Topic: ${topic}, Audience: ${audience}, Goal: ${contentGoal}
Every field must be specific enough that a writer could produce a finished draft without asking a single clarifying question.
Return JSON with: workingTitle, targetKeyword, audienceSegment, audience, searchIntent, outline, keyTalkingPoints, recommendedCTA, suggestedInternalLinks, suggestedLeadMagnet`,
          config: {
            responseMimeType: "application/json",
            responseSchema: schemaStep7,
            temperature: 0.2
          }
        })
      );
      if (!result7.text) {
        throw new Error("Step 7 (Execution Brief) returned empty response.");
      }
      const step7 = JSON.parse(result7.text.trim());

      const reportData = {
        audienceAnalysis: step1,
        searchIntentMapping: { opportunities: step2 },
        editorialGapAnalysis: step3,
        blogIdeas: step4.blogIdeas,
        linkedinIdeas: step4.linkedinIdeas,
        newsletterIdeas: step4.newsletterIdeas,
        prioritizedOpportunities: step6,
        executionBrief: step7
      };
      res.json({ success: true, report: reportData });
    } catch (error: any) {
      console.error("Content strategy generation error:", error);
      res.status(500).json({
        success: false,
        error: error.message || "An unexpected error occurred during model analysis.",
      });
    }
  });

  // API endpoint for parsing a custom scenario description into strategy parameters
  app.post("/api/parse-scenario", async (req, res) => {
    try {
      const { scenario } = req.body;
      if (!scenario || !scenario.trim()) {
        return res.status(400).json({ error: "No scenario description was provided." });
      }

      const ai = getGeminiClient();

      const parsePrompt = `You are a professional growth marketer and search content strategist.
Analyze the following custom strategic content scenario description:
"${scenario}"

Extract and recommend the optimal strategic parameters for our Content Strategy Generator.
Fill in the parameters with highly specific, non-cliché, professional growth-oriented descriptions.

Strictly map the extracted parameters into the output schema.
- contentGoal MUST be exactly one of: "Thought Leadership", "Lead Generation", "Traffic", "Product Adoption", "Brand Awareness".
- platforms MUST be an array containing at least one of: "Blog", "LinkedIn", "Newsletter".`;

      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          topic: { type: Type.STRING, description: "Extracted/formulated content focus or core topic area" },
          audience: { type: Type.STRING, description: "Specific target audience cohort" },
          industry: { type: Type.STRING, description: "Industry vertical context" },
          contentGoal: { type: Type.STRING, description: "Recommended conversion KPI goal" },
          platforms: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Optimal distribution channels list" }
        },
        required: ["topic", "audience", "industry", "contentGoal", "platforms"]
      };

      const result = await callGeminiWithRetry((modelName) => 
        ai.models.generateContent({
          model: modelName,
          contents: parsePrompt,
          config: {
            responseMimeType: "application/json",
            responseSchema,
            temperature: 0.1,
          },
        })
      );

      const responseText = result.text;
      if (!responseText) {
        throw new Error("No response returned from the extractor.");
      }

      const extractedData = JSON.parse(responseText.trim());
      res.json({ success: true, parameters: extractedData });
    } catch (error: any) {
      console.error("Scenario parsing error:", error);
      res.status(500).json({
        success: false,
        error: error.message || "An unexpected error occurred during scenario extraction.",
      });
    }
  });

  // API endpoint to retrieve past generated strategy blueprints
  app.get("/api/history", (req, res) => {
    try {
      const dataDir = path.join(process.cwd(), "data");
      const filePath = path.join(dataDir, "blueprints.json");
      
      if (!fs.existsSync(filePath)) {
        return res.json({ blueprints: [] });
      }
      
      const fileContent = fs.readFileSync(filePath, "utf-8");
      const parsed = JSON.parse(fileContent);
      res.json(parsed);
    } catch (error: any) {
      console.error("Error retrieving history:", error);
      res.status(500).json({ error: error.message || "Failed to retrieve blueprint history" });
    }
  });

  // API endpoint to save a newly generated strategy blueprint
  app.post("/api/history/save", (req, res) => {
    try {
      const { blueprint } = req.body;
      if (!blueprint) {
        return res.status(400).json({ error: "No blueprint provided to save." });
      }

      const dataDir = path.join(process.cwd(), "data");
      const filePath = path.join(dataDir, "blueprints.json");

      // Create data directory if it doesn't exist
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      let historyData = { blueprints: [] as any[] };
      if (fs.existsSync(filePath)) {
        try {
          const fileContent = fs.readFileSync(filePath, "utf-8");
          historyData = JSON.parse(fileContent);
          if (!Array.isArray(historyData.blueprints)) {
            historyData.blueprints = [];
          }
        } catch (e) {
          // If the file exists but has corrupt JSON, reset it
          historyData = { blueprints: [] };
        }
      }

      // Add the new blueprint to the front of the array
      historyData.blueprints.unshift(blueprint);

      // Keep maximum 50 blueprints, trim older ones if over limit
      if (historyData.blueprints.length > 50) {
        historyData.blueprints = historyData.blueprints.slice(0, 50);
      }

      // Write updated array back to blueprints.json
      fs.writeFileSync(filePath, JSON.stringify(historyData, null, 2), "utf-8");

      res.json({ success: true });
    } catch (error: any) {
      console.error("Error saving history:", error);
      res.status(500).json({ error: error.message || "Failed to save blueprint history" });
    }
  });

  // API endpoint for interactive strategist refinement chat
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, history, context } = req.body;

      if (!message) {
        return res.status(400).json({ error: "No message specified." });
      }

      const ai = getGeminiClient();

      // Build context summary for agent priming
      const contextPrompt = context 
        ? `You are discussing a content strategy report for the Topic: "${context.topic}" (Industry: "${context.industry}", Target Audience: "${context.audience}", Goal: "${context.contentGoal}").`
        : "You are an elite, high-leverage content strategist consulting a user on content ideation and distribution.";

      // Filter out leading model/assistant messages to ensure Gemini chat starts with a "user" turn
      const chatHistory = (history || [])
        .filter((msg: any, idx: number) => {
          const role = msg.role === "user" ? "user" : "model";
          if (role !== "user" && !history.slice(0, idx).some((m: any) => m.role === "user")) {
            return false;
          }
          return true;
        })
        .map((msg: any) => ({
          role: msg.role === "user" ? "user" : "model",
          parts: [{ text: msg.content || msg.text || "" }]
        }));

      // Append introductory prompt to set persona
      const systemInstruction = `${contextPrompt} Always speak like a highly experienced growth CMO, editorial director, and world-class SEO authority. Give actionable, expert advice. Skip surface-level recommendations, fluff, and pleasantries. Focus on CTR, distribution mechanics, psychological triggers, and editorial positioning. Keep answers tight, structured, and extremely practical.`;

      const contents = [
        ...chatHistory,
        { role: "user", parts: [{ text: message }] }
      ];

      const response = await callGeminiWithRetry((modelName) => 
        ai.models.generateContent({
          model: modelName,
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        })
      );

      res.json({ success: true, response: response.text });
    } catch (error: any) {
      console.error("Strategist chat error:", error);
      res.status(500).json({
        success: false,
        error: error.message || "An error occurred during interactive chat.",
      });
    }
  });

  // Serve static assets out of /dist in production mode, or run Vite middleware in development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] Agentic Content Strategist running on host 0.0.0.0, port ${PORT}`);
  });
}

startServer();
